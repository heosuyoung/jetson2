import cv2
import mediapipe as mp
import numpy as np
from scipy.spatial import distance as dist
import time
import json
import os
import argparse
import subprocess
import sys
from collections import deque
import pickle

# 라이브러리 자동 설치 및 확인
def check_and_install_libraries():
    """필요한 라이브러리들을 확인하고 설치합니다."""
    required_libraries = {
        'face_recognition': 'face-recognition',
        'ultralytics': 'ultralytics',
        'sklearn': 'scikit-learn'
    }
    
    missing_libraries = []
    
    for lib_name, pip_name in required_libraries.items():
        try:
            __import__(lib_name)
            print(f"[INFO] {lib_name} 라이브러리가 설치되어 있습니다.")
        except ImportError:
            print(f"[WARNING] {lib_name} 라이브러리가 설치되어 있지 않습니다.")
            missing_libraries.append(pip_name)
    
    if missing_libraries:
        print("[INFO] 누락된 라이브러리를 설치합니다...")
        for lib in missing_libraries:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
                print(f"[INFO] {lib} 설치 완료")
            except subprocess.CalledProcessError:
                print(f"[ERROR] {lib} 설치 실패")
                return False
    
    return True

# 라이브러리 확인 및 설치
if not check_and_install_libraries():
    print("[ERROR] 필요한 라이브러리 설치에 실패했습니다.")
    sys.exit(1)

# 이제 라이브러리들을 import
import face_recognition
from ultralytics import YOLO
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

# ---------------------------
# 실행 인자 설정
# ---------------------------
parser = argparse.ArgumentParser()
parser.add_argument("--user_id", type=str, default="DriverA")
parser.add_argument("--measure_time", type=int, default=300)
parser.add_argument("--eye_ar_ratio", type=float, default=0.6)
parser.add_argument("--pitch_ratio", type=float, default=2.0)
parser.add_argument("--yaw_ratio", type=float, default=3.0)
parser.add_argument("--roll_ratio", type=float, default=2.0)
parser.add_argument("--use_ml", action="store_true", help="Use machine learning model")
parser.add_argument("--collect_data", action="store_true", help="Collect training data")
args = parser.parse_args()

# ---------------------------
# 파일 경로 설정
# ---------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
DATA_DIR = os.path.join(BASE_DIR, "data")

YOLO_MODEL_PATH = os.path.join(MODEL_DIR, "best.pt")
FACE_DB_PATH = os.path.join(DATA_DIR, "registered_faces.json")
BASELINE_FILE = os.path.join(DATA_DIR, "baseline.json")
ML_MODEL_PATH = os.path.join(DATA_DIR, f"ml_model_{args.user_id}.pkl")
TRAINING_DATA_PATH = os.path.join(DATA_DIR, f"training_data_{args.user_id}.pkl")

os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

# YOLO 모델 로드
if not os.path.exists(YOLO_MODEL_PATH):
    raise FileNotFoundError(f"YOLO 모델 파일을 찾을 수 없습니다: {YOLO_MODEL_PATH}")

model = YOLO(YOLO_MODEL_PATH)

# ---------------------------
# MediaPipe 설정
# ---------------------------
mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# ---------------------------
# Ratio 값 세팅
# ---------------------------
RATIOS = {
    "EYE_AR_RATIO": args.eye_ar_ratio,
    "PITCH_RATIO": args.pitch_ratio,
    "YAW_RATIO": args.yaw_ratio,
    "ROLL_RATIO": args.roll_ratio
}

# ---------------------------
# 상태 추적을 위한 전역 변수
# ---------------------------
COUNTER_DROWSY_EYE = 0
COUNTER_GAZE_DEVIATION = 0
COUNTER_PHONE_USAGE = 0

LAST_DROWSY_TIME = 0
LAST_GAZE_TIME = 0
LAST_PHONE_USAGE_TIME = 0

WARNING_COOLDOWN_TIME = 5

# 데이터 수집용 변수
data_buffer = deque(maxlen=30)  # 최근 30프레임 저장
ml_model = None
scaler = None

# ---------------------------
# 머신러닝 모델 관리
# ---------------------------
def load_ml_model(user_id):
    """사용자별 머신러닝 모델을 로드합니다."""
    model_path = os.path.join(DATA_DIR, f"ml_model_{user_id}.pkl")
    scaler_path = os.path.join(DATA_DIR, f"scaler_{user_id}.pkl")
    
    if os.path.exists(model_path) and os.path.exists(scaler_path):
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        with open(scaler_path, 'rb') as f:
            scaler = pickle.load(f)
        print(f"[INFO] ML model loaded for {user_id}")
        return model, scaler
    return None, None

def save_ml_model(user_id, model, scaler):
    """머신러닝 모델을 저장합니다."""
    model_path = os.path.join(DATA_DIR, f"ml_model_{user_id}.pkl")
    scaler_path = os.path.join(DATA_DIR, f"scaler_{user_id}.pkl")
    
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    with open(scaler_path, 'wb') as f:
        pickle.dump(scaler, f)
    print(f"[INFO] ML model saved for {user_id}")

def train_ml_model(user_id, training_data):
    """머신러닝 모델을 훈련합니다."""
    if len(training_data) < 100:  # 최소 100개 샘플 필요
        print("[WARNING] Not enough training data. Need at least 100 samples.")
        return None, None
    
    X = []
    y = []
    
    for data_point in training_data:
        features = [
            data_point['ear'],
            data_point['pitch'],
            data_point['yaw'],
            data_point['roll'],
            data_point['ear_std'],  # EAR 표준편차
            data_point['pitch_std'],  # Pitch 표준편차
            data_point['time_since_start'],  # 시작 후 경과 시간
            data_point['blink_count'],  # 깜빡임 횟수
        ]
        X.append(features)
        y.append(data_point['label'])  # 0: 정상, 1: 졸음, 2: 시선이탈
    
    # 데이터 정규화
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # 랜덤 포레스트 모델 훈련
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_scaled, y)
    
    print(f"[INFO] ML model trained with {len(training_data)} samples")
    return model, scaler

def extract_features(ear_values, pitch_values, yaw_values, roll_values, current_time, start_time):
    """특징을 추출합니다."""
    if len(ear_values) < 5:  # 최소 5프레임 필요
        return None
    
    features = {
        'ear': np.mean(ear_values[-5:]),  # 최근 5프레임 평균
        'pitch': np.mean(pitch_values[-5:]),
        'yaw': np.mean(yaw_values[-5:]),
        'roll': np.mean(roll_values[-5:]),
        'ear_std': np.std(ear_values[-10:]),  # 최근 10프레임 표준편차
        'pitch_std': np.std(pitch_values[-10:]),
        'time_since_start': current_time - start_time,
        'blink_count': sum(1 for e in ear_values[-30:] if e < 0.2),  # 최근 30프레임 중 깜빡임
    }
    return features

def predict_with_ml(features, model, scaler):
    """머신러닝 모델로 예측합니다."""
    if features is None or model is None:
        return None
    
    feature_vector = [
        features['ear'],
        features['pitch'],
        features['yaw'],
        features['roll'],
        features['ear_std'],
        features['pitch_std'],
        features['time_since_start'],
        features['blink_count'],
    ]
    
    # 정규화
    feature_scaled = scaler.transform([feature_vector])
    
    # 예측
    prediction = model.predict(feature_scaled)[0]
    probability = model.predict_proba(feature_scaled)[0]
    
    return prediction, probability

# ---------------------------
# Baseline 관리 함수들
# ---------------------------
def load_baseline(file_path, user_id):
    """사용자별 baseline 데이터를 로드합니다."""
    if not os.path.exists(file_path):
        return None
    with open(file_path, "r") as f:
        data = json.load(f)
    return data.get(user_id)

def save_baseline(file_path, user_id, baseline):
    """사용자별 baseline 데이터를 저장합니다."""
    data = {}
    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            data = json.load(f)
    data[user_id] = baseline
    with open(file_path, "w") as f:
        json.dump(data, f, indent=4)
    print(f"[INFO] Baseline saved for {user_id}")

def auto_measure_baseline(user_id, measure_time):
    """사용자의 정상 상태를 측정하여 baseline을 생성합니다."""
    print(f"[INFO] Measuring baseline for {user_id} for {measure_time} seconds...")
    print("[INFO] Please look at the camera normally. (eyes open, head straight)")
    
    cap = cv2.VideoCapture(0)
    start_time = time.time()
    ear_values, pitch_values, yaw_values, roll_values = [], [], [], []
    
    with mp_face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as face_mesh:
        while time.time() - start_time < measure_time:
            ret, frame = cap.read()
            if not ret:
                break
                
            frame = cv2.flip(frame, 1)
            img_h, img_w = frame.shape[:2]
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb_frame)
            
            if results.multi_face_landmarks:
                for face_landmarks in results.multi_face_landmarks:
                    # EAR 계산
                    left_eye_points = [(int(face_landmarks.landmark[i].x * img_w), 
                                       int(face_landmarks.landmark[i].y * img_h)) 
                                      for i in [33, 160, 158, 133, 153, 144]]
                    right_eye_points = [(int(face_landmarks.landmark[i].x * img_w), 
                                        int(face_landmarks.landmark[i].y * img_h)) 
                                       for i in [362, 385, 387, 373, 380, 374]]
                    
                    left_ear = calculate_ear(left_eye_points)
                    right_ear = calculate_ear(right_eye_points)
                    ear = (left_ear + right_ear) / 2.0
                    
                    # 고개 자세 계산
                    pitch, yaw, roll = estimate_head_pose(face_landmarks, frame.shape)
                    
                    if pitch is not None and yaw is not None and roll is not None:
                        ear_values.append(ear)
                        pitch_values.append(abs(pitch))
                        yaw_values.append(abs(yaw))
                        roll_values.append(abs(roll))
            
            # 진행률 표시
            elapsed = time.time() - start_time
            progress = int((elapsed / measure_time) * 100)
            cv2.putText(frame, f"Measuring Baseline... {progress}%", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, f"Time left: {measure_time - int(elapsed)}s", (50, 100),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            cv2.imshow('Baseline Measurement', frame)
            if cv2.waitKey(1) & 0xFF == 27:
                break
    
    cap.release()
    cv2.destroyAllWindows()
    
    if len(ear_values) == 0:
        print("[ERROR] Face not detected. Please try again.")
        return None
    
    baseline = {
        "BASELINE_EYE_AR": sum(ear_values) / len(ear_values),
        "BASELINE_PITCH": sum(pitch_values) / len(pitch_values),
        "BASELINE_YAW": sum(yaw_values) / len(yaw_values),
        "BASELINE_ROLL": sum(roll_values) / len(roll_values)
    }
    
    save_baseline(BASELINE_FILE, user_id, baseline)
    print(f"[INFO] Baseline measurement complete: {baseline}")
    return baseline

# ---------------------------
# 기존 함수들 (v1ai_model.py에서 가져옴)
# ---------------------------
def calculate_ear(eye_landmarks):
    """눈의 EAR(Eye Aspect Ratio)를 계산합니다."""
    A = dist.euclidean(eye_landmarks[1], eye_landmarks[5])
    B = dist.euclidean(eye_landmarks[2], eye_landmarks[4])
    C = dist.euclidean(eye_landmarks[0], eye_landmarks[3])
    ear = (A + B) / (2.0 * C)
    return ear

def estimate_head_pose(face_landmarks, image_shape):
    """고개 자세(Pitch, Yaw, Roll)를 추정합니다."""
    img_h, img_w, _ = image_shape
    
    model_points = np.array([
        (0.0, 0.0, 0.0),            # 1: Nose tip
        (0.0, -330.0, -65.0),       # 152: Chin
        (-225.0, 170.0, -135.0),    # 33: Left eye left corner
        (225.0, 170.0, -135.0),     # 263: Right eye right corner
        (-150.0, -150.0, -125.0),   # 61: Left mouth corner
        (150.0, -150.0, -125.0)     # 291: Right mouth corner
    ], dtype="double")

    if len(face_landmarks.landmark) < 468:
        return None, None, None

    image_points = np.array([
        (face_landmarks.landmark[1].x * img_w, face_landmarks.landmark[1].y * img_h),
        (face_landmarks.landmark[152].x * img_w, face_landmarks.landmark[152].y * img_h),
        (face_landmarks.landmark[33].x * img_w, face_landmarks.landmark[33].y * img_h),
        (face_landmarks.landmark[263].x * img_w, face_landmarks.landmark[263].y * img_h),
        (face_landmarks.landmark[61].x * img_w, face_landmarks.landmark[61].y * img_h),
        (face_landmarks.landmark[291].x * img_w, face_landmarks.landmark[291].y * img_h)
    ], dtype="double")

    focal_length = 1 * img_w
    center = (img_w / 2, img_h / 2)
    camera_matrix = np.array(
        [[focal_length, 0, center[0]],
         [0, focal_length, center[1]],
         [0, 0, 1]], dtype="double"
    )

    dist_coeffs = np.zeros((4, 1))

    success, rotation_vector, translation_vector = cv2.solvePnP(
        model_points, image_points, camera_matrix, dist_coeffs, flags=cv2.SOLVEPNP_ITERATIVE
    )

    if not success:
        return None, None, None

    rmat, _ = cv2.Rodrigues(rotation_vector)
    
    sy = np.sqrt(rmat[0,0] * rmat[0,0] + rmat[1,0] * rmat[1,0])
    singular = sy < 1e-6

    if not singular:
        x = np.arctan2(rmat[2,1], rmat[2,2])
        y = np.arctan2(-rmat[2,0], sy)
        z = np.arctan2(rmat[1,0], rmat[0,0])
    else:
        x = np.arctan2(-rmat[1,2], rmat[1,1])
        y = np.arctan2(-rmat[2,0], sy)
        z = 0

    pitch = np.degrees(x)
    yaw = np.degrees(y)
    roll = np.degrees(z)

    return pitch, yaw, roll

def draw_face_landmarks(frame, face_landmarks):
    """얼굴 랜드마크를 그립니다."""
    mp_drawing.draw_landmarks(
        image=frame,
        landmark_list=face_landmarks,
        connections=mp_face_mesh.FACEMESH_TESSELATION,
        landmark_drawing_spec=None,
        connection_drawing_spec=mp_drawing_styles.get_default_face_mesh_tesselation_style())
    mp_drawing.draw_landmarks(
        image=frame,
        landmark_list=face_landmarks,
        connections=mp_face_mesh.FACEMESH_CONTOURS,
        landmark_drawing_spec=None,
        connection_drawing_spec=mp_drawing_styles.get_default_face_mesh_contours_style())
    mp_drawing.draw_landmarks(
        image=frame,
        landmark_list=face_landmarks,
        connections=mp_face_mesh.FACEMESH_IRISES,
        landmark_drawing_spec=None,
        connection_drawing_spec=mp_drawing_styles.get_default_face_mesh_iris_connections_style())

def display_info_on_frame(frame, screen_width, avg_ear, pitch, yaw, roll, baseline=None, ml_prediction=None):
    """화면에 정보를 표시합니다."""
    cv2.putText(frame, f"EAR: {avg_ear:.2f}", (screen_width - 200, 120),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
    cv2.putText(frame, f"Pitch: {pitch:.1f}", (screen_width - 200, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, f"Yaw: {yaw:.1f}", (screen_width - 200, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, f"Roll: {roll:.1f}", (screen_width - 200, 90),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    if baseline:
        cv2.putText(frame, f"Baseline EAR: {baseline['BASELINE_EYE_AR']:.2f}", (screen_width - 200, 150),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
    
    if ml_prediction is not None:
        prediction_text = f"ML: {ml_prediction}"
        cv2.putText(frame, prediction_text, (screen_width - 200, 180),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 2)

# ---------------------------
# 하이브리드 감지 함수들
# ---------------------------
def check_drowsiness_hybrid(frame, avg_ear, pitch, baseline, ratios, current_time, ml_prediction=None):
    """규칙 기반 + 머신러닝 하이브리드 졸음 감지"""
    global COUNTER_DROWSY_EYE, LAST_DROWSY_TIME
    
    drowsiness_detected = False
    terminal_message = ""

    # 규칙 기반 감지
    eye_threshold = baseline["BASELINE_EYE_AR"] * ratios["EYE_AR_RATIO"]
    pitch_threshold = baseline["BASELINE_PITCH"] * ratios["PITCH_RATIO"]

    is_eyes_closed = (avg_ear < eye_threshold)
    is_head_down = (pitch < pitch_threshold)
    is_eyes_very_closed = (avg_ear < eye_threshold * 0.8)

    rule_based_score = 0
    if is_eyes_very_closed and is_head_down:
        rule_based_score = 2
    elif is_eyes_closed and is_head_down:
        rule_based_score = 1

    # 머신러닝 예측
    ml_score = 0
    if ml_prediction is not None:
        if ml_prediction == 1:  # 졸음
            ml_score = 2
        elif ml_prediction == 0:  # 정상
            ml_score = 0

    # 하이브리드 판단
    combined_score = rule_based_score + ml_score
    
    if combined_score >= 2:  # 규칙 기반 + ML 모두 위험하거나, 하나가 매우 위험할 때
        COUNTER_DROWSY_EYE += 1
    elif combined_score >= 1:
        COUNTER_DROWSY_EYE += 0.5
    else:
        COUNTER_DROWSY_EYE = 0

    if COUNTER_DROWSY_EYE >= 10:
        drowsiness_detected = True
        if current_time - LAST_DROWSY_TIME > WARNING_COOLDOWN_TIME:
            cv2.putText(frame, "DROWSINESS ALERT! (Hybrid)", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            terminal_message = f"DROWSINESS DETECTED: Rule={rule_based_score}, ML={ml_score}"
            LAST_DROWSY_TIME = current_time
    
    return drowsiness_detected, terminal_message

def check_distraction_hybrid(frame, yaw, roll, baseline, ratios, current_time, ml_prediction=None):
    """규칙 기반 + 머신러닝 하이브리드 시선 이탈 감지"""
    global COUNTER_GAZE_DEVIATION, LAST_GAZE_TIME

    gaze_deviation_detected = False
    terminal_message = ""

    # 규칙 기반 감지
    yaw_threshold = baseline["BASELINE_YAW"] * ratios["YAW_RATIO"]
    roll_threshold = baseline["BASELINE_ROLL"] * ratios["ROLL_RATIO"]

    yaw_deviation = abs(yaw) > yaw_threshold
    roll_deviation = abs(roll) > roll_threshold
    
    rule_based_score = 0
    if yaw_deviation and roll_deviation:
        rule_based_score = 2
    elif yaw_deviation or roll_deviation:
        rule_based_score = 1

    # 머신러닝 예측
    ml_score = 0
    if ml_prediction is not None:
        if ml_prediction == 2:  # 시선이탈
            ml_score = 2
        elif ml_prediction == 0:  # 정상
            ml_score = 0

    # 하이브리드 판단
    combined_score = rule_based_score + ml_score
    
    if combined_score >= 2:
        COUNTER_GAZE_DEVIATION += 1
    elif combined_score >= 1:
        COUNTER_GAZE_DEVIATION += 0.5
    else:
        COUNTER_GAZE_DEVIATION = 0

    if COUNTER_GAZE_DEVIATION >= 10:
        gaze_deviation_detected = True
        if current_time - LAST_GAZE_TIME > WARNING_COOLDOWN_TIME:
            cv2.putText(frame, "DISTRACTION ALERT! (Hybrid)", (50, 150),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
            terminal_message = f"DISTRACTION DETECTED: Rule={rule_based_score}, ML={ml_score}"
            LAST_GAZE_TIME = current_time
            
    return gaze_deviation_detected, terminal_message

# ---------------------------
# 휴대폰 감지 함수들
# ---------------------------
def run_object_detection(model, frame):
    """YOLO 모델을 사용한 객체 감지"""
    results = model(frame, verbose=False)
    detected_objects = []
    for r in results:
        boxes = r.boxes
        for box in boxes:
            class_id = int(box.cls)
            class_name = model.names[class_id]
            conf = float(box.conf)
            if class_name == 'device' and conf > 0.5:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                detected_objects.append({'class': class_name, 'bbox': [x1, y1, x2, y2], 'conf': conf})
    return detected_objects

def check_phone_usage(frame, detected_objects, current_time):
    """휴대폰 사용 감지"""
    global COUNTER_PHONE_USAGE, LAST_PHONE_USAGE_TIME

    phone_usage_detected = False
    terminal_message = ""

    if detected_objects:
        COUNTER_PHONE_USAGE += 1
        for obj in detected_objects:
            if obj['class'] == 'device':
                bbox = obj['bbox']
                cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (0, 255, 0), 2)
                cv2.putText(frame, "Device", (bbox[0], bbox[1] - 10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    else:
        COUNTER_PHONE_USAGE = 0

    if COUNTER_PHONE_USAGE >= 10:
        phone_usage_detected = True
        if current_time - LAST_PHONE_USAGE_TIME > WARNING_COOLDOWN_TIME:
            cv2.putText(frame, "PHONE USAGE DETECTED!", (50, 200),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 165, 255), 2)
            terminal_message = "PHONE USAGE DETECTED"
            LAST_PHONE_USAGE_TIME = current_time
    
    return phone_usage_detected, terminal_message

# ---------------------------
# 얼굴 인식 함수들
# ---------------------------
def load_registered_faces():
    """등록된 얼굴 데이터를 로드합니다."""
    if os.path.exists(FACE_DB_PATH):
        with open(FACE_DB_PATH, 'r') as f:
            data = json.load(f)
        return {name: np.array(enc) for name, enc in data.items()}
    return {}

def save_registered_faces(registered_faces):
    """얼굴 데이터를 저장합니다."""
    serializable_faces = {name: enc.tolist() for name, enc in registered_faces.items()}
    with open(FACE_DB_PATH, 'w') as f:
        json.dump(serializable_faces, f, indent=4)

def register_driver_face(frame, user_name):
    """운전자 얼굴을 등록합니다."""
    face_locations = face_recognition.face_locations(frame)
    if not face_locations or len(face_locations) > 1:
        cv2.putText(frame, "Face not detected properly!", (50, 250), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        return False
    
    encoding = face_recognition.face_encodings(frame, face_locations)[0]
    faces = load_registered_faces()
    faces[user_name] = encoding
    save_registered_faces(faces)
    
    cv2.putText(frame, f"Registered: {user_name}", (50, 250), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    return True

def identify_driver(frame):
    """운전자를 식별합니다."""
    face_locations = face_recognition.face_locations(frame)
    if not face_locations or len(face_locations) > 1:
        cv2.putText(frame, "Face not detected properly.", (50, 250), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        return None
    
    encoding = face_recognition.face_encodings(frame, face_locations)[0]
    faces = load_registered_faces()
    
    if not faces:
        cv2.putText(frame, "No registered drivers found.", (50, 250), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        return None
    
    known_encodings = list(faces.values())
    names = list(faces.keys())
    distances = face_recognition.face_distance(known_encodings, encoding)
    best_match = np.argmin(distances)
    
    if distances[best_match] < 0.35:
        identified_name = names[best_match]
        cv2.putText(frame, f"Welcome, {identified_name}!", (50, 250), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        return identified_name
    else:
        cv2.putText(frame, "Unknown Driver!", (50, 250), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        return None

# ---------------------------
# 메인 모니터링 함수
# ---------------------------
def run_driver_monitoring_system():
    """메인 운전자 모니터링 시스템"""
    global COUNTER_DROWSY_EYE, COUNTER_GAZE_DEVIATION, COUNTER_PHONE_USAGE
    global LAST_DROWSY_TIME, LAST_GAZE_TIME, LAST_PHONE_USAGE_TIME
    global ml_model, scaler, data_buffer

    # Baseline 로드 또는 측정
    baseline = load_baseline(BASELINE_FILE, args.user_id)
    if not baseline:
        print(f"[INFO] No baseline found for {args.user_id}. Starting measurement...")
        baseline = auto_measure_baseline(args.user_id, args.measure_time)
        if not baseline:
            print("[ERROR] Baseline measurement failed.")
            return

    print(f"[INFO] Using baseline for {args.user_id}: {baseline}")

    # 머신러닝 모델 로드
    if args.use_ml:
        ml_model, scaler = load_ml_model(args.user_id)
        if ml_model is None:
            print("[WARNING] ML model not found. Using rule-based detection only.")

    # 웹캠 초기화
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Cannot open webcam.")
        return

    screen_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    screen_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # 눈 랜드마크 인덱스
    LEFT_EYE_LANDMARKS = [33, 160, 158, 133, 153, 144]
    RIGHT_EYE_LANDMARKS = [362, 385, 387, 373, 380, 374]

    identification_status = "Not Identified"
    user_to_register = args.user_id

    # 데이터 수집용 변수
    start_time = time.time()
    ear_history = []
    pitch_history = []
    yaw_history = []
    roll_history = []

    # MediaPipe Face Mesh 초기화
    with mp_face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    ) as face_mesh:

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                print("Failed to grab frame.")
                break

            frame = cv2.flip(frame, 1)
            image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image_rgb.flags.writeable = False
            results = face_mesh.process(image_rgb)
            image_rgb.flags.writeable = True
            frame = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)

            drowsiness_status_message = ""
            distraction_status_message = ""
            phone_usage_status_message = ""

            # 객체 감지
            detected_objects = run_object_detection(model, frame)

            pitch, yaw, roll = None, None, None
            ml_prediction = None

            if results.multi_face_landmarks:
                for face_landmarks in results.multi_face_landmarks:
                    # 얼굴 랜드마크 그리기
                    draw_face_landmarks(frame, face_landmarks)

                    # EAR 계산
                    left_eye_points = [(int(face_landmarks.landmark[i].x * screen_width),
                                       int(face_landmarks.landmark[i].y * screen_height))
                                      for i in LEFT_EYE_LANDMARKS]
                    right_eye_points = [(int(face_landmarks.landmark[i].x * screen_width),
                                        int(face_landmarks.landmark[i].y * screen_height))
                                       for i in RIGHT_EYE_LANDMARKS]
                    avg_ear = (calculate_ear(left_eye_points) + calculate_ear(right_eye_points)) / 2.0

                    # 고개 자세 추정
                    pitch, yaw, roll = estimate_head_pose(face_landmarks, frame.shape)

                    if pitch is not None and yaw is not None and roll is not None:
                        # 히스토리 업데이트
                        ear_history.append(avg_ear)
                        pitch_history.append(abs(pitch))
                        yaw_history.append(abs(yaw))
                        roll_history.append(abs(roll))

                        # 머신러닝 예측
                        if args.use_ml and ml_model is not None:
                            features = extract_features(ear_history, pitch_history, yaw_history, roll_history, time.time(), start_time)
                            if features is not None:
                                ml_prediction, ml_probability = predict_with_ml(features, ml_model, scaler)

                        # 하이브리드 감지 함수들 호출
                        _, drowsiness_status_message = check_drowsiness_hybrid(
                            frame, avg_ear, pitch, baseline, RATIOS, time.time(), ml_prediction)
                        
                        _, distraction_status_message = check_distraction_hybrid(
                            frame, yaw, roll, baseline, RATIOS, time.time(), ml_prediction)
                        
                        _, phone_usage_status_message = check_phone_usage(
                            frame, detected_objects, time.time())

                        # 정보 표시
                        display_info_on_frame(frame, screen_width, avg_ear, pitch, yaw, roll, baseline, ml_prediction)
            else:
                # 얼굴이 감지되지 않으면 카운터 초기화
                COUNTER_DROWSY_EYE = 0
                COUNTER_GAZE_DEVIATION = 0
                COUNTER_PHONE_USAGE = 0

            # 상태 및 조작 가이드 표시
            cv2.putText(frame, f"ID Status: {identification_status}", (50, screen_height - 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
            
            control_text = "R:Register I:Identify B:Baseline +/-:Sensitivity"
            if args.use_ml:
                control_text += " T:Train 1:Normal 2:Drowsy 3:Distracted"
            control_text += " ESC:Exit"
            
            cv2.putText(frame, control_text, (50, screen_height - 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            # 터미널 출력
            if drowsiness_status_message:
                print(f"[{time.strftime('%H:%M:%S', time.localtime())}] {drowsiness_status_message}")
            elif distraction_status_message:
                print(f"[{time.strftime('%H:%M:%S', time.localtime())}] {distraction_status_message}")
            elif phone_usage_status_message:
                print(f"[{time.strftime('%H:%M:%S', time.localtime())}] {phone_usage_status_message}")

            cv2.imshow('Hybrid Driver Monitoring System', frame)

            # 키 입력 처리
            key = cv2.waitKey(5) & 0xFF
            if key == 27:  # ESC
                break
            elif key == ord('r'):  # Register
                print(f"Attempting to register face for '{user_to_register}'...")
                if register_driver_face(frame, user_to_register):
                    identification_status = f"Registered {user_to_register}"
                else:
                    identification_status = "Registration Failed"
            elif key == ord('i'):  # Identify
                print("Attempting to identify driver...")
                identified_name = identify_driver(frame)
                identification_status = identified_name if identified_name else "Identification Failed"
            elif key == ord('b'):  # Re-measure Baseline
                print("Re-measuring baseline...")
                baseline = auto_measure_baseline(args.user_id, args.measure_time)
                if baseline:
                    print("Baseline re-measurement completed.")
            elif key == ord('+'):  # 감도 증가
                RATIOS["EYE_AR_RATIO"] *= 0.9
                RATIOS["PITCH_RATIO"] *= 0.9
                RATIOS["YAW_RATIO"] *= 0.9
                RATIOS["ROLL_RATIO"] *= 0.9
                print(f"[INFO] Sensitivity increased: {RATIOS}")
            elif key == ord('-'):  # 감도 감소
                RATIOS["EYE_AR_RATIO"] *= 1.1
                RATIOS["PITCH_RATIO"] *= 1.1
                RATIOS["YAW_RATIO"] *= 1.1
                RATIOS["ROLL_RATIO"] *= 1.1
                print(f"[INFO] Sensitivity decreased: {RATIOS}")
            elif key == ord('t') and args.use_ml:  # Train ML model
                print("Training ML model...")
                if len(data_buffer) > 100:
                    model, scaler = train_ml_model(args.user_id, list(data_buffer))
                    if model is not None:
                        save_ml_model(args.user_id, model, scaler)
                        ml_model, scaler = model, scaler
                        print("ML model training completed.")
                else:
                    print("Not enough data for training. Need at least 100 samples.")
            elif key == ord('1'):  # Collect Normal Data
                if pitch is not None and yaw is not None and roll is not None:
                    features = extract_features(ear_history, pitch_history, yaw_history, roll_history, time.time(), start_time)
                    if features is not None:
                        features['label'] = 0  # Normal
                        data_buffer.append(features)
                        print(f"[INFO] Normal data collected. Total: {len(data_buffer)}")
            elif key == ord('2'):  # Collect Drowsy Data
                if pitch is not None and yaw is not None and roll is not None:
                    features = extract_features(ear_history, pitch_history, yaw_history, roll_history, time.time(), start_time)
                    if features is not None:
                        features['label'] = 1  # Drowsy
                        data_buffer.append(features)
                        print(f"[INFO] Drowsy data collected. Total: {len(data_buffer)}")
            elif key == ord('3'):  # Collect Distracted Data
                if pitch is not None and yaw is not None and roll is not None:
                    features = extract_features(ear_history, pitch_history, yaw_history, roll_history, time.time(), start_time)
                    if features is not None:
                        features['label'] = 2  # Distracted
                        data_buffer.append(features)
                        print(f"[INFO] Distracted data collected. Total: {len(data_buffer)}")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_driver_monitoring_system()
